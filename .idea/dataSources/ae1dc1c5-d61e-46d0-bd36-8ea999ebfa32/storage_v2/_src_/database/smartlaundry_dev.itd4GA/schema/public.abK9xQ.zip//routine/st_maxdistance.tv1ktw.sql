create function st_maxdistance(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT public._ST_MaxDistance(public.ST_ConvexHull($1), public.ST_ConvexHull($2))$$;

alter function st_maxdistance(geometry, geometry) owner to postgres;

