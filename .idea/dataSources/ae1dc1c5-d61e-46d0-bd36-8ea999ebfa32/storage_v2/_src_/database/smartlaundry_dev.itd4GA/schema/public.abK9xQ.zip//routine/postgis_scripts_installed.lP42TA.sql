create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.6.0'::text || $rev$ 3.6.0 $rev$) AS version $$;

alter function postgis_scripts_installed() owner to postgres;

