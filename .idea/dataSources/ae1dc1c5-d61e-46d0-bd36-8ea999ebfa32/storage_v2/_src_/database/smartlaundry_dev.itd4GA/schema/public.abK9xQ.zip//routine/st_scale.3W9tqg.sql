create function st_scale(geometry, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_Scale($1, $2, $3, 1)$$;

alter function st_scale(geometry, double precision, double precision) owner to postgres;

