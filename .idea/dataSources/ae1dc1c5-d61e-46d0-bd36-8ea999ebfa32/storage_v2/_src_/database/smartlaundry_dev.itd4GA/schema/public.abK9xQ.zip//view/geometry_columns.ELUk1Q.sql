create view geometry_columns
            (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type) as
SELECT current_database()::character varying(256)                                         AS f_table_catalog,
       n.nspname                                                                          AS f_table_schema,
       c.relname                                                                          AS f_table_name,
       a.attname                                                                          AS f_geometry_column,
       COALESCE(postgis_typmod_dims(a.atttypmod), 2)                                      AS coord_dimension,
       COALESCE(NULLIF(postgis_typmod_srid(a.atttypmod), 0), 0)                           AS srid,
       replace(replace(COALESCE(NULLIF(upper(postgis_typmod_type(a.atttypmod)), 'GEOMETRY'::text), 'GEOMETRY'::text),
                       'ZM'::text, ''::text), 'Z'::text, ''::text)::character varying(30) AS type
FROM pg_class c
         JOIN pg_attribute a ON a.attrelid = c.oid AND NOT a.attisdropped
         JOIN pg_namespace n ON c.relnamespace = n.oid
         JOIN pg_type t ON a.atttypid = t.oid
WHERE (c.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'm'::"char", 'f'::"char", 'p'::"char"]))
  AND NOT c.relname = 'raster_columns'::name
  AND t.typname = 'geometry'::name
  AND NOT pg_is_other_temp_schema(c.relnamespace)
  AND has_table_privilege(c.oid, 'SELECT'::text);

alter table geometry_columns
    owner to postgres;

grant select on geometry_columns to public;

